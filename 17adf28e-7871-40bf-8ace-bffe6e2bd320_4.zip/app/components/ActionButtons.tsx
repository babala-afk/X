'use client';

interface ActionButtonsProps {
  onAction: (actionType: 'health' | 'happiness' | 'energy' | 'hunger') => void;
  canInteract: boolean;
  characterStatus: 'healthy' | 'warning' | 'dead';
}

export default function ActionButtons({ onAction, canInteract, characterStatus }: ActionButtonsProps) {
  const buttonClass = `flex items-center justify-center gap-3 p-4 rounded-xl font-medium transition-all duration-200 whitespace-nowrap ${
    canInteract && characterStatus !== 'dead'
      ? 'hover:scale-105 cursor-pointer'
      : 'opacity-50 cursor-not-allowed'
  }`;

  const handleClick = (actionType: 'health' | 'happiness' | 'energy' | 'hunger') => {
    if (canInteract && characterStatus !== 'dead') {
      onAction(actionType);
    }
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">💝 Bakım Seçenekleri</h3>
      
      <div className="space-y-3">
        <div
          onClick={() => handleClick('health')}
          className={`${buttonClass} bg-red-100 hover:bg-red-200 text-red-800 border-2 border-red-200`}
        >
          <span className="text-2xl">❤️</span>
          <span>Sağlık Ver</span>
          <span className="text-sm text-red-600">(+0.1%)</span>
        </div>

        <div
          onClick={() => handleClick('happiness')}
          className={`${buttonClass} bg-yellow-100 hover:bg-yellow-200 text-yellow-800 border-2 border-yellow-200`}
        >
          <span className="text-2xl">😊</span>
          <span>Mutluluk Ver</span>
          <span className="text-sm text-yellow-600">(+0.08%)</span>
        </div>

        <div
          onClick={() => handleClick('energy')}
          className={`${buttonClass} bg-blue-100 hover:bg-blue-200 text-blue-800 border-2 border-blue-200`}
        >
          <span className="text-2xl">⚡</span>
          <span>Enerji Ver</span>
          <span className="text-sm text-blue-600">(+0.1%)</span>
        </div>

        <div
          onClick={() => handleClick('hunger')}
          className={`${buttonClass} bg-orange-100 hover:bg-orange-200 text-orange-800 border-2 border-orange-200`}
        >
          <span className="text-2xl">🍽️</span>
          <span>Yemek Ver</span>
          <span className="text-sm text-orange-600">(-0.12%)</span>
        </div>
      </div>

      {!canInteract && characterStatus !== 'dead' && (
        <div className="bg-purple-100 border-2 border-purple-200 rounded-xl p-4 text-center">
          <div className="text-purple-800 font-medium">⏰ Bir sonraki işlem için bekliyorsunuz</div>
          <div className="text-sm text-purple-600 mt-1">Her saat başı sadece 1 işlem yapılabilir</div>
        </div>
      )}

      {characterStatus === 'dead' && (
        <div className="bg-gray-100 border-2 border-gray-200 rounded-xl p-4 text-center">
          <div className="text-gray-800 font-medium">💀 Karakter öldü!</div>
          <div className="text-sm text-gray-600 mt-1">Yeni karakter otomatik oluşturuluyor...</div>
        </div>
      )}
    </div>
  );
}