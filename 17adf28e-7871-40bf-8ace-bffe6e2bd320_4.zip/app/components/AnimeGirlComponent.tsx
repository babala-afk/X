'use client';

interface AnimeGirlComponentProps {
  status: 'healthy' | 'warning' | 'dead';
}

export default function AnimeGirlComponent({ status }: AnimeGirlComponentProps) {
  const getCharacterImage = () => {
    switch (status) {
      case 'healthy':
        return 'https://readdy.ai/api/search-image?query=Beautiful%20happy%20anime%20girl%20with%20pink%20hair%2C%20bright%20colorful%20kawaii%20style%2C%20cheerful%20expression%2C%20sparkles%20around%20her%2C%20vibrant%20colors%2C%20pastel%20background%2C%20cute%20anime%20art%20style%2C%20detailed%20digital%20illustration%2C%20manga%20style&width=300&height=400&seq=anime-girl-happy&orientation=portrait';
      case 'warning':
        return 'https://readdy.ai/api/search-image?query=Worried%20anime%20girl%20with%20pink%20hair%2C%20concerned%20facial%20expression%2C%20slightly%20sad%20kawaii%20style%2C%20muted%20colors%2C%20anime%20art%20style%2C%20detailed%20digital%20illustration%2C%20manga%20style%20character%20design&width=300&height=400&seq=anime-girl-worried&orientation=portrait';
      case 'dead':
        return 'https://readdy.ai/api/search-image?query=Sad%20anime%20girl%20with%20gray%20hair%20lying%20down%2C%20exhausted%20expression%2C%20dark%20muted%20colors%2C%20melancholic%20kawaii%20style%2C%20anime%20art%20style%2C%20detailed%20digital%20illustration%2C%20manga%20style%20character&width=300&height=400&seq=anime-girl-dead&orientation=portrait';
      default:
        return 'https://readdy.ai/api/search-image?query=Beautiful%20happy%20anime%20girl%20with%20pink%20hair%2C%20bright%20colorful%20kawaii%20style%2C%20cheerful%20expression%2C%20sparkles%20around%20her%2C%20vibrant%20colors%2C%20pastel%20background%2C%20cute%20anime%20art%20style%2C%20detailed%20digital%20illustration%2C%20manga%20style&width=300&height=400&seq=anime-girl-default&orientation=portrait';
    }
  };

  const getCharacterGlow = () => {
    switch (status) {
      case 'healthy':
        return 'drop-shadow-lg filter';
      case 'warning':
        return 'drop-shadow-md filter';
      case 'dead':
        return 'grayscale filter opacity-70';
      default:
        return 'drop-shadow-lg filter';
    }
  };

  const getBorderColor = () => {
    switch (status) {
      case 'healthy':
        return 'border-pink-300';
      case 'warning':
        return 'border-yellow-300';
      case 'dead':
        return 'border-gray-300';
      default:
        return 'border-pink-300';
    }
  };

  return (
    <div className="relative">
      {/* Arka plan efekti */}
      <div className={`absolute inset-0 rounded-full blur-xl opacity-20 ${
        status === 'healthy' ? 'bg-pink-300' :
        status === 'warning' ? 'bg-yellow-300' :
        'bg-gray-300'
      }`} style={{ transform: 'scale(1.2)' }}></div>
      
      {/* Ana karakter resmi */}
      <div className={`relative w-72 h-96 rounded-2xl overflow-hidden border-4 ${getBorderColor()} ${getCharacterGlow()} transition-all duration-1000`}>
        <img
          src={getCharacterImage()}
          alt="Anime Girl"
          className="w-full h-full object-cover object-top"
        />
      </div>
      
      {/* Animasyonlu kalpler - sadece sağlıklı durumda */}
      {status === 'healthy' && (
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(8)].map((_, i) => (
            <div
              key={i}
              className="absolute animate-bounce text-pink-400 opacity-60"
              style={{
                left: `${10 + i * 12}%`,
                top: `${5 + (i % 4) * 25}%`,
                animationDelay: `${i * 0.3}s`,
                animationDuration: '2.5s'
              }}
            >
              {i % 3 === 0 ? '💖' : i % 3 === 1 ? '✨' : '🌸'}
            </div>
          ))}
        </div>
      )}

      {/* Uyarı efekti */}
      {status === 'warning' && (
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-2 left-1/2 transform -translate-x-1/2 animate-pulse">
            <span className="text-3xl">😰</span>
          </div>
          <div className="absolute bottom-2 right-2 animate-bounce">
            <span className="text-2xl">⚠️</span>
          </div>
        </div>
      )}

      {/* Ölüm efekti */}
      {status === 'dead' && (
        <div className="absolute inset-0 pointer-events-none bg-black bg-opacity-20 rounded-2xl flex items-center justify-center">
          <div className="text-center">
            <div className="text-4xl mb-2">💀</div>
            <div className="text-white font-bold text-lg bg-black bg-opacity-50 px-3 py-1 rounded-full">
              Öldü
            </div>
          </div>
        </div>
      )}

      {/* Durum göstergesi */}
      <div className="absolute -bottom-4 left-1/2 transform -translate-x-1/2">
        <div className={`px-4 py-2 rounded-full text-sm font-medium shadow-lg ${
          status === 'healthy' ? 'bg-pink-100 text-pink-800 border-2 border-pink-300' :
          status === 'warning' ? 'bg-yellow-100 text-yellow-800 border-2 border-yellow-300' :
          'bg-gray-100 text-gray-800 border-2 border-gray-300'
        }`}>
          {status === 'healthy' ? '🌸 Mutlu ve Sağlıklı' :
           status === 'warning' ? '😰 Endişeli' :
           '💀 Hasta'}
        </div>
      </div>
    </div>
  );
}