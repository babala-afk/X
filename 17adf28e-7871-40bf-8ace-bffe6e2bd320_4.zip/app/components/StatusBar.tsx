'use client';

interface StatusBarProps {
  characterData: {
    health: number;
    happiness: number;
    energy: number;
    hunger: number;
  };
}

export default function StatusBar({ characterData }: StatusBarProps) {
  const getStatusColor = (value: number, type: 'health' | 'happiness' | 'energy' | 'hunger') => {
    switch (type) {
      case 'health':
        if (value > 4) return 'text-red-600';
        if (value > 3) return 'text-orange-600';
        return 'text-red-600';
      case 'happiness':
        if (value < 1) return 'text-red-600';
        if (value < 1.5) return 'text-orange-600';
        return 'text-yellow-600';
      case 'energy':
        if (value < 1) return 'text-red-600';
        if (value < 1.5) return 'text-orange-600';
        return 'text-blue-600';
      case 'hunger':
        if (value > 4) return 'text-red-600';
        if (value > 3) return 'text-orange-600';
        return 'text-orange-600';
      default:
        return 'text-gray-600';
    }
  };

  const getProgressColor = (value: number, type: 'health' | 'happiness' | 'energy' | 'hunger') => {
    switch (type) {
      case 'health':
        if (value > 4) return 'bg-red-500';
        if (value > 3) return 'bg-orange-500';
        return 'bg-red-500';
      case 'happiness':
        if (value < 1) return 'bg-red-500';
        if (value < 1.5) return 'bg-orange-500';
        return 'bg-yellow-500';
      case 'energy':
        if (value < 1) return 'bg-red-500';
        if (value < 1.5) return 'bg-orange-500';
        return 'bg-blue-500';
      case 'hunger':
        if (value > 4) return 'bg-red-500';
        if (value > 3) return 'bg-orange-500';
        return 'bg-orange-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getProgressBg = (type: 'health' | 'happiness' | 'energy' | 'hunger') => {
    switch (type) {
      case 'health':
        return 'bg-red-100';
      case 'happiness':
        return 'bg-yellow-100';
      case 'energy':
        return 'bg-blue-100';
      case 'hunger':
        return 'bg-orange-100';
      default:
        return 'bg-gray-100';
    }
  };

  const getProgressWidth = (value: number, maxValue: number, type: 'health' | 'happiness' | 'energy' | 'hunger') => {
    if (type === 'hunger') {
      // Açlık için ters çalışır - düşük değer iyi
      return Math.min(((5 - value) / 5) * 100, 100);
    }
    return Math.min((value / maxValue) * 100, 100);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">📊 Karakter Durumu</h3>
      
      <div className="space-y-4">
        {/* Sağlık */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <div className="flex items-center gap-2">
              <span className="text-xl">❤️</span>
              <span className="font-medium text-gray-700">Sağlık</span>
            </div>
            <span className={`font-bold ${getStatusColor(characterData.health, 'health')}`}>
              {characterData.health.toFixed(1)}%
            </span>
          </div>
          <div className={`w-full ${getProgressBg('health')} rounded-full h-3`}>
            <div
              className={`h-3 rounded-full transition-all duration-500 ${getProgressColor(characterData.health, 'health')}`}
              style={{ width: `${getProgressWidth(characterData.health, 6, 'health')}%` }}
            ></div>
          </div>
        </div>

        {/* Mutluluk */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <div className="flex items-center gap-2">
              <span className="text-xl">😊</span>
              <span className="font-medium text-gray-700">Mutluluk</span>
            </div>
            <span className={`font-bold ${getStatusColor(characterData.happiness, 'happiness')}`}>
              {characterData.happiness.toFixed(1)}%
            </span>
          </div>
          <div className={`w-full ${getProgressBg('happiness')} rounded-full h-3`}>
            <div
              className={`h-3 rounded-full transition-all duration-500 ${getProgressColor(characterData.happiness, 'happiness')}`}
              style={{ width: `${getProgressWidth(characterData.happiness, 5, 'happiness')}%` }}
            ></div>
          </div>
        </div>

        {/* Enerji */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <div className="flex items-center gap-2">
              <span className="text-xl">⚡</span>
              <span className="font-medium text-gray-700">Enerji</span>
            </div>
            <span className={`font-bold ${getStatusColor(characterData.energy, 'energy')}`}>
              {characterData.energy.toFixed(1)}%
            </span>
          </div>
          <div className={`w-full ${getProgressBg('energy')} rounded-full h-3`}>
            <div
              className={`h-3 rounded-full transition-all duration-500 ${getProgressColor(characterData.energy, 'energy')}`}
              style={{ width: `${getProgressWidth(characterData.energy, 8, 'energy')}%` }}
            ></div>
          </div>
        </div>

        {/* Açlık */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <div className="flex items-center gap-2">
              <span className="text-xl">🍽️</span>
              <span className="font-medium text-gray-700">Tokluk</span>
            </div>
            <span className={`font-bold ${getStatusColor(characterData.hunger, 'hunger')}`}>
              {(5 - characterData.hunger).toFixed(1)}%
            </span>
          </div>
          <div className={`w-full ${getProgressBg('hunger')} rounded-full h-3`}>
            <div
              className={`h-3 rounded-full transition-all duration-500 ${getProgressColor(characterData.hunger, 'hunger')}`}
              style={{ width: `${getProgressWidth(characterData.hunger, 5, 'hunger')}%` }}
            ></div>
          </div>
        </div>
      </div>
    </div>
  );
}