
'use client';

import { useState, useEffect } from 'react';

interface TimeCounterProps {
  nextActionTime: number;
  onTimeUp: () => void;
}

export default function TimeCounter({ nextActionTime, onTimeUp }: TimeCounterProps) {
  const [timeLeft, setTimeLeft] = useState('');

  useEffect(() => {
    const updateTimer = () => {
      const now = Date.now();
      const diff = nextActionTime - now;

      if (diff <= 0) {
        onTimeUp();
        return;
      }

      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      setTimeLeft(`${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);

    return () => clearInterval(interval);
  }, [nextActionTime, onTimeUp]);

  return (
    <div className="bg-orange-50 border-2 border-orange-200 rounded-xl p-4 text-center">
      <div className="text-orange-800 font-medium mb-2">⏰ Sonraki işlem için kalan süre:</div>
      <div className="text-2xl font-bold text-orange-600 font-mono" suppressHydrationWarning={true}>
        {timeLeft}
      </div>
      <div className="text-sm text-orange-600 mt-1">saat:dakika:saniye</div>
    </div>
  );
}
