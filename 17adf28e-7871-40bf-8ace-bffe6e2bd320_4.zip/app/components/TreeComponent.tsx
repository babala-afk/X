
'use client';

interface TreeComponentProps {
  status: 'healthy' | 'warning' | 'dead';
}

export default function TreeComponent({ status }: TreeComponentProps) {
  const getTreeEmoji = () => {
    switch (status) {
      case 'healthy':
        return '🌳';
      case 'warning':
        return '🌾';
      case 'dead':
        return '🪴';
      default:
        return '🌳';
    }
  };

  const getTreeColor = () => {
    switch (status) {
      case 'healthy':
        return 'text-green-600';
      case 'warning':
        return 'text-yellow-600';
      case 'dead':
        return 'text-gray-500';
      default:
        return 'text-green-600';
    }
  };

  const getTreeGlow = () => {
    switch (status) {
      case 'healthy':
        return 'drop-shadow-lg filter';
      case 'warning':
        return 'drop-shadow-md filter';
      case 'dead':
        return 'grayscale filter';
      default:
        return 'drop-shadow-lg filter';
    }
  };

  return (
    <div className="relative">
      {/* Arka plan efekti */}
      <div className={`absolute inset-0 rounded-full blur-xl opacity-30 ${
        status === 'healthy' ? 'bg-green-300' :
        status === 'warning' ? 'bg-yellow-300' :
        'bg-gray-300'
      }`} style={{ transform: 'scale(1.5)' }}></div>
      
      {/* Ana ağaç */}
      <div className={`relative text-8xl md:text-9xl transition-all duration-1000 ${getTreeColor()} ${getTreeGlow()}`}>
        {getTreeEmoji()}
      </div>
      
      {/* Animasyonlu parçacıklar - sadece sağlıklı durumda */}
      {status === 'healthy' && (
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className="absolute animate-bounce text-green-400 opacity-60"
              style={{
                left: `${20 + i * 15}%`,
                top: `${10 + (i % 3) * 20}%`,
                animationDelay: `${i * 0.5}s`,
                animationDuration: '2s'
              }}
            >
              ✨
            </div>
          ))}
        </div>
      )}

      {/* Uyarı efekti */}
      {status === 'warning' && (
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-2 animate-pulse">
            <span className="text-2xl">⚠️</span>
          </div>
        </div>
      )}

      {/* Ölüm efekti */}
      {status === 'dead' && (
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-2">
            <span className="text-2xl opacity-70">💀</span>
          </div>
        </div>
      )}
    </div>
  );
}
