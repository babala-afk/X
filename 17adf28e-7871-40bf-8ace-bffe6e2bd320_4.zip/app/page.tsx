'use client';

import { useState, useEffect } from 'react';
import AnimeGirlComponent from './components/AnimeGirlComponent';
import ActionButtons from './components/ActionButtons';
import StatusBar from './components/StatusBar';
import TimeCounter from './components/TimeCounter';

export default function HomePage() {
  const [characterData, setCharacterData] = useState({
    health: 2,
    happiness: 1,
    energy: 5,
    hunger: 3
  });
  const [characterStatus, setCharacterStatus] = useState('healthy');
  const [canInteract, setCanInteract] = useState(true);
  const [nextActionTime, setNextActionTime] = useState<number | null>(null);
  const [characterBirthTime, setCharacterBirthTime] = useState<number>(Date.now());
  const [characterAge, setCharacterAge] = useState('');

  // Karakterin yaşını hesapla
  useEffect(() => {
    const updateAge = () => {
      const now = Date.now();
      const ageInMs = now - characterBirthTime;
      
      const days = Math.floor(ageInMs / (1000 * 60 * 60 * 24));
      const hours = Math.floor((ageInMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((ageInMs % (1000 * 60 * 60)) / (1000 * 60));

      if (days > 0) {
        setCharacterAge(`${days} gün, ${hours} saat`);
      } else if (hours > 0) {
        setCharacterAge(`${hours} saat, ${minutes} dakika`);
      } else {
        setCharacterAge(`${minutes} dakika`);
      }
    };

    updateAge();
    const interval = setInterval(updateAge, 60000); // Her dakika güncelle

    return () => clearInterval(interval);
  }, [characterBirthTime]);

  // Karakterin durumunu kontrol et
  useEffect(() => {
    const checkCharacterHealth = () => {
      const { health, happiness, energy, hunger } = characterData;
      
      if (health > 4 || happiness < 1 || energy < 1 || hunger > 4) {
        if (characterStatus !== 'dead') {
          // Karakter öldüğünde otomatik olarak yeni karakter oluştur
          setTimeout(() => {
            const newBirthTime = Date.now();
            const initialData = { health: 2, happiness: 1, energy: 5, hunger: 3 };
            setCharacterData(initialData);
            setCharacterBirthTime(newBirthTime);
            setCharacterStatus('healthy');
            localStorage.setItem('characterData', JSON.stringify(initialData));
            localStorage.setItem('characterBirthTime', newBirthTime.toString());
          }, 3000); // 3 saniye bekle, sonra yeni karakter oluştur
        }
        setCharacterStatus('dead');
      } else if (health > 3 || happiness < 1.5 || energy < 1.5 || hunger > 3) {
        setCharacterStatus('warning');
      } else {
        setCharacterStatus('healthy');
      }
    };

    checkCharacterHealth();
  }, [characterData, characterStatus]);

  // Sayfa yüklendiğinde son işlem zamanını kontrol et
  useEffect(() => {
    const lastActionTime = localStorage.getItem('lastCharacterAction');
    if (lastActionTime) {
      const timePassed = Date.now() - parseInt(lastActionTime);
      const oneHour = 60 * 60 * 1000;
      
      if (timePassed < oneHour) {
        setCanInteract(false);
        setNextActionTime(parseInt(lastActionTime) + oneHour);
      }
    }

    // Kayıtlı veriyi yükle
    const savedData = localStorage.getItem('characterData');
    if (savedData) {
      setCharacterData(JSON.parse(savedData));
    }

    // Karakterin doğum zamanını yükle
    const savedBirthTime = localStorage.getItem('characterBirthTime');
    if (savedBirthTime) {
      setCharacterBirthTime(parseInt(savedBirthTime));
    } else {
      // İlk kez açılıyorsa doğum zamanını kaydet
      const currentTime = Date.now();
      setCharacterBirthTime(currentTime);
      localStorage.setItem('characterBirthTime', currentTime.toString());
    }
  }, []);

  const handleAction = (actionType: 'health' | 'happiness' | 'energy' | 'hunger') => {
    if (!canInteract) return;

    const newData = { ...characterData };
    
    switch (actionType) {
      case 'health':
        newData.health += 0.1;
        break;
      case 'happiness':
        newData.happiness += 0.08;
        break;
      case 'energy':
        newData.energy += 0.1;
        break;
      case 'hunger':
        newData.hunger -= 0.12; // Açlık azalır
        if (newData.hunger < 0) newData.hunger = 0;
        break;
    }

    // Değerleri güncelle
    setCharacterData(newData);
    
    // Veriyi kaydet
    localStorage.setItem('characterData', JSON.stringify(newData));
    localStorage.setItem('lastCharacterAction', Date.now().toString());
    
    // Etkileşimi devre dışı bırak
    setCanInteract(false);
    setNextActionTime(Date.now() + 60 * 60 * 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-100 to-purple-50">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-pink-800 mb-2">🌸 Anime Kızı Bakımı</h1>
          <p className="text-gray-600">Anime kızına her saat başı bakım yapabilirsiniz</p>
        </div>

        {/* Karakter Yaşı */}
        <div className="text-center mb-6">
          <div className="inline-block bg-white rounded-lg shadow-md px-6 py-3">
            <div className="text-sm text-gray-600">🕐 Yaşadığı süre:</div>
            <div className="text-lg font-bold text-pink-700" suppressHydrationWarning={true}>
              {characterAge}
            </div>
          </div>
        </div>

        {/* Ana Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Sol Taraf - Anime Kızı */}
          <div className="flex flex-col items-center">
            <AnimeGirlComponent status={characterStatus} />
            <div className="mt-4 text-center">
              <div className={`inline-block px-4 py-2 rounded-full text-sm font-medium ${
                characterStatus === 'healthy' ? 'bg-pink-100 text-pink-800' :
                characterStatus === 'warning' ? 'bg-yellow-100 text-yellow-800' :
                'bg-gray-100 text-gray-800'
              }`}>
                {characterStatus === 'healthy' ? '😊 Mutlu' :
                 characterStatus === 'warning' ? '😰 Endişeli' :
                 '💀 Öldü - Yeni karakter oluşuyor...'}
              </div>
            </div>
          </div>

          {/* Sağ Taraf - Kontroller */}
          <div className="space-y-6">
            <StatusBar characterData={characterData} />
            <ActionButtons 
              onAction={handleAction} 
              canInteract={canInteract}
              characterStatus={characterStatus}
            />
            {!canInteract && nextActionTime && (
              <TimeCounter nextActionTime={nextActionTime} onTimeUp={() => {
                setCanInteract(true);
                setNextActionTime(null);
              }} />
            )}
          </div>
        </div>

        {/* Kritik Seviyeler Bilgisi */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">⚠️ Kritik Seviyeler</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
            <div className="bg-red-50 p-3 rounded-lg">
              <div className="font-medium text-red-800">❤️ Sağlık</div>
              <div className="text-red-600">%4'ten fazla = Hasta olma</div>
            </div>
            <div className="bg-yellow-50 p-3 rounded-lg">
              <div className="font-medium text-yellow-800">😊 Mutluluk</div>
              <div className="text-yellow-600">%1'in altı = Depresyon</div>
            </div>
            <div className="bg-blue-50 p-3 rounded-lg">
              <div className="font-medium text-blue-800">⚡ Enerji</div>
              <div className="text-blue-600">%1'in altı = Bitkinlik</div>
            </div>
            <div className="bg-orange-50 p-3 rounded-lg">
              <div className="font-medium text-orange-800">🍽️ Açlık</div>
              <div className="text-orange-600">%4'ten fazla = Aç kalma</div>
            </div>
          </div>
        </div>

        {/* Otomatik Yenilenme Bilgisi */}
        {characterStatus === 'dead' && (
          <div className="bg-purple-50 border-2 border-purple-200 rounded-lg p-4 text-center">
            <div className="text-purple-800 font-medium">🔄 Karakter öldüğünde otomatik olarak yeni karakter oluşturulur</div>
            <div className="text-sm text-purple-600 mt-1">3 saniye içinde yeni karakter başlayacak...</div>
          </div>
        )}
      </div>
    </div>
  );
}